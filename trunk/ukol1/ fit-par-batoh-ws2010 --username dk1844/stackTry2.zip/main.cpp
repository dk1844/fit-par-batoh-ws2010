/* 
 * File:   main.cpp
 * Author: Daniel
 *
 * Created on 30. září 2010, 18:29
 */

#include <cstdlib>
#include <stack>
#include <vector>
#include <iostream>

#include <Node.h>

using namespace std;

/*
 * 
 */

//not used now
//template = uvod tak, abych mohl pracovat s gen. tridou
template<class T> void descStack(stack<T> neco) {
    cout << "vypis:" << endl;

    if (neco.empty()) {
        cout << "-- NIC --" << endl;
    } else {
        T top = neco.top();
        cout << "-- neco --" << endl <<
                "top[0] = " << top[0] << endl <<
                "size = " << neco.size() << endl;
    }

}

int main(int argc, char** argv) {

    vector<float> volumes(5, 1.05);
    vector<float> values(5, 1.04);


    //stack<vector<int> > mujstack;
    //descStack(mujstack);
    //mujstack.push(v0);
    //mujstack.push(v1);
    //mujstack.push(v3);

    //descStack(mujstack);

    Node nod(2);

    nod.print();

    Node a;
    Node b;

    nod.expand(&a, &b, &volumes, &values);

    a.print();
    b.print();

    cout << "---------" << endl;

    Node a0, a1;
    Node b0, b1;

    a.expand(&a0, &a1, &volumes, &values);
    b.expand(&b0, &b1, &volumes, &values);

    a0.print();
    a1.print();

    b0.print();
    b1.print();

    return 0;
}

