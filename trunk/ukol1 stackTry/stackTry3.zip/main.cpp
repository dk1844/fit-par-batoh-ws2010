/* 
 * File:   main.cpp
 * Author: Daniel
 *
 * Created on 30. září 2010, 18:29
 */

#include <cstdlib>

#include <stack>
#include <vector>


#include <iostream>  // I/O
#include <fstream>   // file I/O
#include <iomanip>   // format manipulation
#include <string>

#include <Node.h>

using namespace std;
/**
 * Prints a vector :)
 */
template<class T> void printVector(vector<T> * vect1, char * name = "") {

    if (name != "") {
        cout << "Vector \"" << name << "\" content:" << endl;
    } else {
        cout << "Vector content:" << endl;
    }
    for (int b = 0; b < (* vect1).size(); b++) {
        cout << (*vect1)[b] << " ";
    }
    cout << endl;
}




//not used now
//template = uvod tak, abych mohl pracovat s gen. tridou
template<class T> void descStack(stack<T> neco) {
    cout << "vypis:" << endl;

    if (neco.empty()) {
        cout << "-- NIC --" << endl;
    } else {
        T top = neco.top();
        cout << "-- neco --" << endl <<
                
                "size = " << neco.size() << endl;
    }

}

void descStack(stack<Node> * neco) {
    cout << "vypis:" << endl;

    if ((*neco).empty()) {
        cout << "-- NIC --" << endl;
    } else {
        cout << "-- stacktop: --" << endl <<
                "top_volumes = " << 
                "size = " << (*neco).size() << endl;
        vector<int>  lcl = (*neco).top().getCurrentContent();
        printVector( &lcl);
    }

}

/**
 * Loads data from filename into vectors volume and value
 * @param filename name of the file loading
 * @param volume vector containing floats with volumes
 * @param value vector containing floats with values
 */
void loadDataFromFile(char * filename, int * items_cnt, vector<float> * volume, vector<float> * value, float * bagSize) {

    ifstream fp_in; // declarations of stream fp_in
    fp_in.open(filename, ios::in); // open the streams


    if (!fp_in) {
        cerr << "File could not be opened" << endl;
        exit(1);
    }

    int count;
    float float_val;

    fp_in >> float_val; // input from file pointer or standard input
    if (!fp_in.good()) {
        cerr << "Wrong format" << endl;
        exit(1);
    }
    (*bagSize) = float_val;

    fp_in >> count; // input from file pointer or standard input
    if (!fp_in.good()) {
        cerr << "Wrong format" << endl;
        exit(1);
    }

    (*items_cnt) = count;

    (*volume).resize(count);
    (*value).resize(count);

    cout << "Expecting 2x" << count << " values." << endl;

    for (int i = 0; i < count; i++) {
        fp_in >> float_val;
        if (!fp_in.good()) {
            cerr << "Wrong format inside" << endl;
            exit(1);
        }
        (*value)[i] = float_val;

        fp_in >> float_val;
        if (!fp_in.good()) {
            cerr << "Wrong format inside" << endl;
            exit(1);
        }
        (*volume)[i] = float_val;

    }

    float dummy;
    fp_in >> dummy;
    if (!fp_in.eof()) {
        cerr << "WARNING: file should have ended, skipping the rest.." << endl;
        // exit(1);
    }

    fp_in.close(); // close the streams
}


int main(int argc, char** argv) {
    if (argc != 2) {
        cerr << "# arguments found = " << (argc - 1) << endl;
        cerr << "USAGE : \"" << argv[0] << " <filename>" << endl;
        return 3;
    }

    vector<float> volumes;
    vector<float> values;
    float bagSize;
    int items_count;
    stack<Node> stack1;
    //stack<int> stack1;

    loadDataFromFile(argv[1], &items_count, &volumes, &values, &bagSize);
    
    //debug only
    cout << "Loaded bag size = " << bagSize << endl;
    cout << "Loaded items count = " << items_count << endl;
    printVector(&volumes, "Volume");
    printVector(&values);



    Node root(items_count);


    //v pripade par. zpracovani zde muzeme expandovat, dokud nemame dost Nodu pro vsechny procesory
    //ted ne, protoze mam jen single thread :)

    Node thisP = root;

    stack1.push(thisP);
    descStack(&stack1);



    while (!stack1.empty()) {
        Node akt = stack1.top();
        stack1.pop(); //remove top
        if(akt.isExpandable()) {
            Node a;
            Node b;
            /*debug - start*/
            cout << "---inner node---" << endl;
            akt.print();
            /*debug - end*/
            akt.expand(&a, &b, &values, &volumes);

            //jen u perspektivnich vratim
            stack1.push(a);
            stack1.push(b);
        } else {
        // tree leaf
            cout << "========leaf======" << endl;
            akt.print();
        }


    }




    return 0;
}

