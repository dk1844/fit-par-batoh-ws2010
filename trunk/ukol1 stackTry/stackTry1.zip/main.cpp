/* 
 * File:   main.cpp
 * Author: Daniel
 *
 * Created on 30. září 2010, 18:29
 */

#include <cstdlib>
#include <stack>
#include <vector>
#include <iostream>

using namespace std;

/*
 * 
 */

//template = uvod tak, abych mohl pracovat s gen. tridou
//template<class T> void vypisStack( stack<T neco>) {
template<class T> void descStack( stack<T> neco) {
    cout << "vypis:" << endl;

    if  (neco.empty()) {
        cout << "-- NIC --" << endl;
    } else {
        T top =  neco.top();
        cout << "-- neco --" << endl <<
                "top[0] = " << top[0] << endl <<
                "size = " << neco.size() << endl;
    }

}

int main(int argc, char** argv) {

    vector<int> v0 (5,0);
    vector<int> v1 (5,1);
    vector<int> v3 (5,3);

    stack<vector<int> > mujstack;


    descStack(mujstack);

    mujstack.push(v0);
    mujstack.push(v1);
    mujstack.push(v3);

    descStack(mujstack);

    return 0;
}

